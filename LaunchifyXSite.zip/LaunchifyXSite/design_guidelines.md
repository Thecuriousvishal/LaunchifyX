# LaunchifyX Design Guidelines

## Design Approach
**Selected Approach**: Modern startup aesthetic with bold typography, gradient highlights, and clean sections. Reference inspiration from contemporary tech startups with high-energy, conversion-focused design.

## Color Palette
- Primary: `#4f46e5` (Indigo)
- Secondary: `#6366f1` (Light Indigo)
- Dark Background: `#0f172a` (Dark Navy)
- Light Background: `#ffffff` (White)
- Use gradient combinations of primary and secondary colors for highlights and CTAs

## Typography
**Font Families**: 
- Headings: Inter or Poppins (Bold/Extrabold weights)
- Body: Inter (Regular/Medium weights)

**Hierarchy**:
- Hero Headlines: Extra large, bold, attention-grabbing (text-5xl to text-7xl)
- Section Headings: Large, bold (text-3xl to text-4xl)
- Subheadings: Medium weight (text-xl to text-2xl)
- Body Text: Regular weight, comfortable reading size (text-base to text-lg)
- CTA Buttons: Medium weight, uppercase or sentence case

## Layout System
**Spacing Units**: Use Tailwind spacing of 4, 8, 12, 16, 20, 24 (p-4, p-8, gap-12, py-16, py-20, py-24)

**Section Padding**: 
- Desktop: py-20 to py-24
- Mobile: py-12 to py-16

**Container Widths**:
- Full sections: w-full with max-w-7xl inner containers
- Content sections: max-w-6xl
- Forms: max-w-2xl

## Component Library

### Navigation
- **Sticky Navbar**: Fixed at top, transparent initially with blur backdrop, solid background on scroll
- Links: Home, About Us, Services, Portfolio, Contact
- Right-aligned CTA: "Get a Quote" button with gradient background
- Mobile: Hamburger menu with smooth slide-in drawer

### Hero Section (Home Page)
- Full viewport height hero with gradient background overlay
- **Headline**: "Launch Your Vision. Build Without Limits." (large, bold, center-aligned)
- **Subheading**: "We help businesses grow through technology, design, and automation." (medium weight, beneath headline)
- **Dual CTAs**: "Get Started" (primary gradient button) and "Work With Us" (outline/secondary button)
- Use a large background image showing technology/startup theme with dark overlay for text readability
- Buttons with blurred backgrounds over the image

### Service Cards
- Grid layout: 3 columns on desktop (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Each card includes: Icon/graphic, service title, description (3-4 lines)
- Services: Web Development (React/Next.js), Mobile App Development (Flutter), Branding & UI/UX, Digital Marketing, AI & Automation Solutions, Custom Software Development
- Hover effect: subtle lift and shadow increase

### Portfolio Showcase
- Masonry or standard grid: 3 columns desktop, 2 tablet, 1 mobile
- 6 project cards with placeholder images
- Each card: Project image, title overlay, brief description on hover
- Click interaction to view project details

### About Section
- Two-column layout (image + content)
- Founder info: Name (Vishal), role (CEO), founding date (Sep 2025)
- Mission statement prominently displayed
- "Why Choose Us" with 4-6 bullet points (icons + short descriptions)

### Testimonials
- 3-column grid with testimonial cards
- Each card: Quote, client name, company/role, optional avatar
- Rotating carousel on mobile

### Contact Form
- Fields: Name, Email, Message (textarea)
- Submit button with gradient background
- Contact info displayed: support@launchifyx.com
- Social links: LinkedIn, Instagram, GitHub icons

### Footer
- Multi-column layout: Company info, Quick Links, Services, Contact
- Social media icons
- Copyright notice: "© 2025 LaunchifyX. All rights reserved."

### Floating Elements
- **Chat Button**: Fixed bottom-right corner, circular, gradient background with message icon
- Pulse animation to draw attention

## Animations
- Smooth page transitions
- Scroll-triggered fade-in animations for sections
- Hover effects on cards and buttons (subtle scale, shadow increase)
- Gradient button animations on hover
- Navbar background transition on scroll
- Keep animations smooth (300-500ms duration, ease-in-out)

## Images
**Required Images**:
1. **Hero Background**: Modern tech/startup workspace or abstract digital visualization (full-width, 100vh)
2. **About Section**: Team working together or founder portrait (medium size, ~500x600px)
3. **Portfolio Items**: 6 project showcase images (1200x800px each)
4. **Service Icons**: Icon graphics for each of 6 services

## Responsive Behavior
- Mobile-first approach
- Breakpoints: sm (640px), md (768px), lg (1024px), xl (1280px)
- Stack multi-column layouts to single column on mobile
- Adjust typography scale for mobile (reduce by 1-2 sizes)
- Touch-friendly button sizes (min 44px height)
- Collapsible mobile navigation

## Special Requirements
- Custom favicon: Letter "L" shaped as minimalist logo
- SEO-optimized meta tags on all pages
- Smooth scrolling behavior for anchor links
- Form validation with error states
- Loading states for interactive elements
import ContactForm from '@/components/ContactForm';

export default function ContactPage() {
  return (
    <div className="pt-16">
      <div className="py-20 bg-gradient-to-br from-primary/10 via-background to-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-extrabold mb-6">Contact Us</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We'd love to hear from you. Let's discuss your project and explore how we can help
          </p>
        </div>
      </div>
      <ContactForm />
    </div>
  );
}

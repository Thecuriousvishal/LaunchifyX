import Portfolio from '@/components/Portfolio';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';

export default function PortfolioPage() {
  return (
    <div className="pt-16">
      <div className="py-20 bg-gradient-to-br from-primary/10 via-background to-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-extrabold mb-6">Our Portfolio</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explore our recent work and see how we've helped businesses transform digitally
          </p>
        </div>
      </div>
      <Portfolio />
      <div className="py-20 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Want to See Your Project Here?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Let's work together to bring your vision to life
          </p>
          <Link href="/quote">
            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-primary/80"
              data-testid="button-start-project"
            >
              Start Your Project
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

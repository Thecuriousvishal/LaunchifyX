import About from '@/components/About';
import Testimonials from '@/components/Testimonials';

export default function AboutPage() {
  return (
    <div className="pt-16">
      <div className="py-20 bg-gradient-to-br from-primary/10 via-background to-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-extrabold mb-6">About LaunchifyX</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Learn more about our mission, vision, and the team behind LaunchifyX
          </p>
        </div>
      </div>
      <About />
      <Testimonials />
    </div>
  );
}

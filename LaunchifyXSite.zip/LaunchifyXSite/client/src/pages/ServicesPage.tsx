import Services from '@/components/Services';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';

export default function ServicesPage() {
  return (
    <div className="pt-16">
      <div className="py-20 bg-gradient-to-br from-primary/10 via-background to-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-extrabold mb-6">Our Services</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Comprehensive digital solutions tailored to your business needs
          </p>
          <Link href="/quote">
            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-primary/80"
              data-testid="button-get-quote"
            >
              Get a Free Quote
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </div>
      <Services />
      <div className="py-20 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Let's discuss your project and how we can help you achieve your goals
          </p>
          <Link href="/contact">
            <Button
              size="lg"
              variant="outline"
              className="bg-background"
              data-testid="button-contact"
            >
              Contact Us Today
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

import ChatButton from '../ChatButton';

export default function ChatButtonExample() {
  return <ChatButton />;
}

import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import ThemeToggle from '@/components/ThemeToggle';
import logoImg from '@assets/launchifyx-logo.jpg';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <div className="fixed top-0 left-0 right-0 z-50 px-4 pt-4">
      <nav
        className={`max-w-7xl mx-auto transition-all duration-300 rounded-full bg-white dark:bg-slate-900 ${
          isScrolled
            ? 'shadow-xl border border-primary/20'
            : 'shadow-lg border border-border/50'
        }`}
      >
        <div className="px-6 sm:px-8">
          <div className="flex items-center justify-between h-14">
            <Link href="/" className="flex items-center gap-3" data-testid="link-home">
              <img src={logoImg} alt="LaunchifyX Logo" className="w-9 h-9 object-contain" />
              <span className="text-lg font-bold text-foreground">
                LaunchifyX
              </span>
            </Link>

            <div className="hidden md:flex items-center gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  href={link.path}
                  className={`text-sm font-medium transition-colors hover-elevate px-3 py-2 rounded-md ${
                    location === link.path ? 'text-primary' : 'text-foreground/80'
                  }`}
                  data-testid={`link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {link.name}
                </Link>
              ))}
              <ThemeToggle />
              <Link href="/quote">
                <Button
                  size="sm"
                  className="bg-gradient-to-r from-primary to-primary/80"
                  data-testid="button-quote"
                >
                  Get a Quote
                </Button>
              </Link>
            </div>

            <div className="md:hidden flex items-center gap-2">
              <ThemeToggle />
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" data-testid="button-menu">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col gap-4 mt-8">
                  {navLinks.map((link) => (
                    <Link
                      key={link.path}
                      href={link.path}
                      className={`text-base font-medium transition-colors hover-elevate px-4 py-2 rounded-md ${
                        location === link.path ? 'text-primary bg-primary/10' : 'text-foreground'
                      }`}
                      data-testid={`mobile-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {link.name}
                    </Link>
                  ))}
                  <Link href="/quote">
                    <Button
                      className="w-full bg-gradient-to-r from-primary to-primary/80"
                      data-testid="button-quote-mobile"
                    >
                      Get a Quote
                    </Button>
                  </Link>
                </div>
              </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}

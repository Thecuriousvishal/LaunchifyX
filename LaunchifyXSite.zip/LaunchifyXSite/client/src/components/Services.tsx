import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Code, Smartphone, Palette, TrendingUp, Bot, Settings } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Website Development',
    description: 'Modern, responsive websites built with React, Next.js, and cutting-edge technologies for optimal performance.',
  },
  {
    icon: Smartphone,
    title: 'Mobile App Development',
    description: 'Native and cross-platform mobile applications using Flutter for seamless user experiences across devices.',
  },
  {
    icon: Palette,
    title: 'Branding & UI/UX',
    description: 'Create memorable brand identities and intuitive user interfaces that engage and convert your audience.',
  },
  {
    icon: TrendingUp,
    title: 'Digital Marketing',
    description: 'Data-driven marketing strategies to boost your online presence and drive measurable business growth.',
  },
  {
    icon: Bot,
    title: 'AI & Automation Solutions',
    description: 'Leverage AI and automation to streamline workflows, reduce costs, and scale your business efficiently.',
  },
  {
    icon: Settings,
    title: 'Custom Software Development',
    description: 'Tailored software solutions designed to solve your unique business challenges and requirements.',
  },
];

export default function Services() {
  return (
    <section className="py-24 bg-background" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Our Services</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive digital solutions to help your business thrive in the modern world
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card
                key={index}
                className="hover-elevate active-elevate-2 transition-all duration-300 cursor-pointer"
                data-testid={`card-service-${index}`}
              >
                <CardHeader>
                  <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

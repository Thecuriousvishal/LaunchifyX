import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ChatButton() {
  const [isPulsing, setIsPulsing] = useState(true);
  const { toast } = useToast();

  const handleClick = () => {
    setIsPulsing(false);
    toast({
      title: 'Chat Feature',
      description: 'Live chat will be available soon. For now, please use the contact form.',
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      <div className="relative">
        {isPulsing && (
          <div className="absolute inset-0 rounded-full bg-primary/30 animate-ping" />
        )}
        <Button
          size="icon"
          className="w-14 h-14 rounded-full bg-gradient-to-r from-primary to-primary/80 shadow-lg hover:shadow-xl transition-all duration-300"
          onClick={handleClick}
          data-testid="button-chat"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}

import { Link } from 'wouter';
import { Github, Linkedin, Instagram, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import logoImg from '@assets/launchifyx-logo.jpg';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    company: [
      { name: 'About Us', path: '/about' },
      { name: 'Our Team', path: '/about' },
      { name: 'Contact', path: '/contact' },
    ],
    services: [
      { name: 'Web Development', path: '/services' },
      { name: 'Mobile Apps', path: '/services' },
      { name: 'Branding', path: '/services' },
      { name: 'AI Solutions', path: '/services' },
    ],
    resources: [
      { name: 'Portfolio', path: '/portfolio' },
      { name: 'Get a Quote', path: '/quote' },
    ],
  };

  return (
    <footer className="bg-muted/30 border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logoImg} alt="LaunchifyX Logo" className="w-10 h-10 object-contain" />
              <span className="text-xl font-bold text-foreground">
                LaunchifyX
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Empowering businesses to launch, grow, and succeed digitally.
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" className="hover-elevate">
                <Linkedin className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="hover-elevate">
                <Instagram className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="hover-elevate">
                <Github className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="hover-elevate">
                <Mail className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.path}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              {footerLinks.services.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.path}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.path}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © {currentYear} LaunchifyX. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground">
              Based in Patna, Bihar, India
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

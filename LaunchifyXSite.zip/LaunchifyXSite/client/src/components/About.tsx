import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Target, Zap, Shield, Users, Trophy } from 'lucide-react';
import founderImg from '@assets/dp1_1763236998484.jpg';

const features = [
  {
    icon: Zap,
    title: 'Fast Delivery',
    description: 'Quick turnaround without compromising on quality',
  },
  {
    icon: Shield,
    title: 'Reliable Solutions',
    description: 'Robust and scalable technology built to last',
  },
  {
    icon: Users,
    title: 'Expert Team',
    description: 'Skilled professionals dedicated to your success',
  },
  {
    icon: Trophy,
    title: 'Proven Results',
    description: 'Track record of delivering exceptional outcomes',
  },
];

export default function About() {
  return (
    <section className="py-24 bg-background" id="about">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <h2 className="text-4xl font-bold mb-6">About LaunchifyX</h2>
            <p className="text-lg text-primary font-semibold mb-4">Your Ideas, Our Code.</p>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              LaunchifyX is a full-stack technology & product agency based in Patna, Bihar. 
              Founded in September 2025, we help startups and businesses turn ideas into 
              powerful digital products.
            </p>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              We specialize in building scalable websites, mobile apps, brand identities, and 
              AI-driven solutions that drive growth and digital transformation.
            </p>
            <div className="bg-primary/5 border border-primary/20 rounded-md p-6 mb-6">
              <div className="flex items-start gap-3">
                <Target className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">Our Mission</h3>
                  <p className="text-muted-foreground">
                    To empower startups and businesses to launch, grow, and succeed digitally with
                    impactful, scalable, and data-driven solutions.
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-muted-foreground">Founded: September 2025</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-muted-foreground">Location: Patna, Bihar, India</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-muted-foreground">Founder & CEO: Vishal Kumar</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-md overflow-hidden">
              <img
                src={founderImg}
                alt="Vishal Kumar - Founder & CEO of LaunchifyX"
                className="w-full h-auto rounded-md"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/95 to-transparent p-6">
                <h3 className="text-2xl font-bold text-foreground mb-1">Vishal Kumar</h3>
                <p className="text-muted-foreground">Founder & CEO</p>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-3xl font-bold text-center mb-12">Why Choose Us</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="text-center hover-elevate transition-all duration-300">
                  <CardContent className="pt-8 pb-8">
                    <div className="w-14 h-14 rounded-md bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <h4 className="font-semibold text-lg mb-2">{feature.title}</h4>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

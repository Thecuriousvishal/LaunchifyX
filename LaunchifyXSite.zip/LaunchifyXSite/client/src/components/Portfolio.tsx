import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import ecommerceImg from '@assets/generated_images/Portfolio_project_ecommerce_4cac0ebf.png';
import mobileAppImg from '@assets/generated_images/Portfolio_project_mobile_app_bdcdef0b.png';
import brandingImg from '@assets/generated_images/Portfolio_project_branding_62ad3d38.png';
import marketingImg from '@assets/generated_images/Portfolio_project_marketing_dashboard_8db5ac0f.png';
import aiAutomationImg from '@assets/generated_images/Portfolio_project_AI_automation_298b10a9.png';
import customSoftwareImg from '@assets/generated_images/Portfolio_project_custom_software_e90a2619.png';

const projects = [
  {
    title: 'E-Commerce Platform',
    category: 'Web Development',
    description: 'Full-featured online store with payment integration and inventory management',
    image: ecommerceImg,
    tags: ['React', 'Node.js', 'Stripe'],
  },
  {
    title: 'Banking Mobile App',
    category: 'Mobile Development',
    description: 'Secure mobile banking application with real-time transaction tracking',
    image: mobileAppImg,
    tags: ['Flutter', 'Firebase', 'API'],
  },
  {
    title: 'Corporate Branding',
    category: 'Branding & Design',
    description: 'Complete brand identity redesign for a growing tech startup',
    image: brandingImg,
    tags: ['Branding', 'UI/UX', 'Design'],
  },
  {
    title: 'Marketing Analytics',
    category: 'Digital Marketing',
    description: 'Comprehensive marketing dashboard with performance insights',
    image: marketingImg,
    tags: ['Analytics', 'SEO', 'Marketing'],
  },
  {
    title: 'AI Workflow Automation',
    category: 'AI & Automation',
    description: 'Intelligent automation system for streamlined business processes',
    image: aiAutomationImg,
    tags: ['AI', 'Automation', 'Integration'],
  },
  {
    title: 'Enterprise CRM',
    category: 'Custom Software',
    description: 'Custom CRM solution tailored for enterprise client management',
    image: customSoftwareImg,
    tags: ['Custom', 'Enterprise', 'CRM'],
  },
];

export default function Portfolio() {
  return (
    <section className="py-24 bg-muted/30" id="portfolio">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Our Portfolio</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore our recent projects and see how we've helped businesses transform digitally
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="overflow-hidden hover-elevate active-elevate-2 transition-all duration-300 cursor-pointer group"
              data-testid={`card-project-${index}`}
            >
              <div className="relative overflow-hidden aspect-video">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                  <div className="text-sm text-foreground/90">{project.description}</div>
                </div>
              </div>
              <CardContent className="p-6">
                <Badge variant="secondary" className="mb-3">
                  {project.category}
                </Badge>
                <h3 className="text-xl font-semibold mb-3">{project.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <Badge key={tagIndex} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
